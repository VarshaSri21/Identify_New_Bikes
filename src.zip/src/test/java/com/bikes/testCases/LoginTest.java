package com.bikes.testCases;

import org.apache.log4j.Logger;
import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.bikes.baseUtils.baseUI;
import com.bikes.pages.Homepage;
import com.bikes.pages.LoginPage;

public class LoginTest extends baseUI {

	LoginPage login = new LoginPage();
	Homepage homepage = new Homepage();
    
	Logger logj=Logger.getLogger(LoginTest.class);
	
	public LoginTest() throws IOException {
		super();
	}
	
	/************************To Test Valid Mail*************************************/
	
	
	 @Test(priority=0, groups = "Regression Test" )
	public void clickLoginValid() throws InterruptedException, IOException {
		logger = report.createTest("ZigWheels Login/Signup with Google");
		setupDriver();
		logj.info("Browser has been invoked Successfully");
		openURL("websiteUrl");
		logj.info("Website is opened");
		homepage.closePopup();
		logj.info("Popup is closed");
		homepage.clickLogin();
		logj.info("Login window is clicked");
		login.validEmailId();
		logj.info("Valid E-Mail ID is given");
		homepage.windowHandle();	
		}
	 
	 
  /**********************To Test Invalid Mail **********************************/
	
	
	@Test(dependsOnMethods="clickLoginValid", groups = "Smoke Test")
	public void clickLoginInvalidEmail() throws InterruptedException, IOException {
		homepage.clickLogin();
		logj.info("Login window opens again");
		login.invalidEmailId();
		logj.info("InValid E-Mail ID is given");
		waitFor(3);
	}
	
	/****************** Report ***********************/		
	@AfterClass(groups = "Smoke Test")
	public void endReport() {

		report.flush();
		logj.info("Report is generated");
		driver.quit();
		logj.info("Browser is Closed");
	}
	
}
