package com.bikes.testCases;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.bikes.baseUtils.baseUI;
import com.bikes.pages.Homepage;
import com.bikes.pages.usedCars;

public class UsedCarsTest extends baseUI {

	public UsedCarsTest() throws IOException {
		super();
	}

	Logger logj=Logger.getLogger(UsedCarsTest.class);
	
	Homepage hpage = new Homepage();
	usedCars carModels = new usedCars();

	/*************************************************************************************
	 * This method is used to call the 'selectChennai' method
	 *************************************************************************************/

	@Test(priority = 0, groups = "Smoke Test")
	public void selectChennai() {
		logger = report.createTest("ZigWheels Used Cars in Chennai - Extracting popular models");
		setupDriver();
		logj.info("Browser has been invoked Successfully");
		openURL("websiteUrl");
		logj.info("Website is opened");
		waitFor(2);
		hpage.closePopup();
		logj.info("Popup is closed");
		hpage.selectChennai();
		logj.info("Chennai is Clicked");
	}

	/*************************************************************************************
	 * This method is used to call the 'getPopularModels' method
	 *************************************************************************************/

	@Test(priority = 1, dependsOnMethods = "selectChennai", groups = "Smoke Test")
	public void getPopularModels() {

		carModels.getPopularModels();
		logj.info("Displayed -The Popular Models Used Cars in Chennai");
	}

	/***************************************************************************************
	 * This method is used to verify the UsedCars page
	 ***************************************************************************************/

	@Test(priority = 2, dependsOnMethods = "getPopularModels", groups = "Regression Test")
	public void verifyChennai() {
		carModels.verifyPlace();
		logj.info("Verified -The Popular Models Used Cars in Chennai");
	}

	/*************************************************************************************
	 * This method is used to close the 'Browser'
	 *************************************************************************************/

	@AfterClass(groups = "Smoke Test")
	public void browserQuit() {
		report.flush();
		logj.info("Report is generated");
		driver.quit();
		logj.info("Browser is Closed");
	}
}
