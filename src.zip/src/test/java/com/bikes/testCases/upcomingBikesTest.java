package com.bikes.testCases;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.apache.log4j.Logger;
import com.bikes.baseUtils.baseUI;
import com.bikes.pages.Homepage;
import com.bikes.pages.bikesHonda;

public class upcomingBikesTest extends baseUI {
	Homepage hpage = new Homepage();
	bikesHonda hbikes = new bikesHonda();

	Logger logj=Logger.getLogger(upcomingBikesTest.class);
	public upcomingBikesTest() throws IOException {
		super();
	}

	/****************** To Test Opening the website ***********************/
	@Test(priority = 0, groups = "Smoke Test")
	public void invokeDriver() {
		logger = report.createTest("ZigWheels Opening the website");
		setupDriver();
		logj.info("Browser has been invoked Successfully");
		openURL("websiteUrl");
	}

	/******************
	 * To Test ZigWheels Upcoming Bikes in India - Extracting Honda models
	 ***********************/
	@Test(priority = 1, groups = "Smoke Test")
	public void upcomBikes() {
		logger = report.createTest("ZigWheels Upcoming Bikes in India - Extracting Honda models");
		hpage.closePopup();
		logj.info("Popup is closed");
		waitFor(2);
		hpage.clickUcBikes();
		logj.info("Upcoming Bikes are Clicked");
		waitFor(2);
	}

	/******************
	 * To Test ZigWheels Upcoming Bikes in India - Selecting Honda Bikes
	 ***********************/
	@Test(dependsOnMethods = "upcomBikes", groups = "Smoke Test")
	public void selectingHbikes() {
		hbikes.selectManufacturer();
		logj.info("Honda is selected from the browser");
		
	}

	/******************
	 * To Test ZigWheels Upcoming Bikes in India - Click View More Bikes
	 ***********************/
	@Test(dependsOnMethods = "selectingHbikes", groups = "Smoke Test")
	public void clickViewMore() {
		hbikes.viewMore(579, 1325);
		logj.info("View More Bikes button is clicked");
	}

	/******************
	 * To Test ZigWheels Upcoming Bikes in India - HondaUp Coming Bikes
	 ***********************/
	@Test(dependsOnMethods = "clickViewMore", groups = "Regression Test")
	public void HondaBikes() {
		hbikes.HondaUpcomingBikes();
		logj.info("Upcoming Honda Bikes are displayed");
	}

	/****************** Reports ***********************/
	@AfterClass(groups = "Smoke Test")
	public void endReport() {

		report.flush();
		logj.info("Report is generated");
		driver.close();
		logj.info("Browser is closed");
	}

}
