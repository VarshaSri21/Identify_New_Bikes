package com.bikes.pages;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.io.IOException;

import com.bikes.baseUtils.baseUI;
import com.bikes.utils.ExcelUtils;
import com.aventstack.extentreports.Status;

public class LoginPage extends baseUI {

	public LoginPage() throws IOException {
		super();
	}

	/****************** Enter Valid MailID ***********************/
	public void validEmailId() {
		System.out.println("/*************************************************************/");
		System.out.println("                            Valid Mail Id                      ");
		System.out.println("/*************************************************************/");

		// Fetching data from the Excel
		String[] data = null;
		try {
			data = ExcelUtils
					.readExcel(System.getProperty("user.dir") + "\\src\\java\\resources\\TestData\\TestData.xlsx");

		} catch (Exception e) {
			e.getMessage();
		}

		// Entering invalid Username
		logger.log(Status.INFO, "Entering the Valid UserName");
		enterText("userName_Id", data[1]);
		waitFor(1);

		// Clicking on Next Button
		logger.log(Status.INFO, "Clicking on Next Button");
		elementClick("nextBtn_ClassName");
		waitFor(1);

		// Getting the Error Message
		logger.log(Status.INFO, "Capturing the Error Message");
		String errMsg = getMessage("containerErrorMsg_Id");
		System.out.println(
				"\n-------------------------------------------------------------------------------------------------------------------------\n");
		System.out.println("\tThe Error Message is : " + errMsg);
		System.out.println(
				"\n-------------------------------------------------------------------------------------------------------------------------\n");

		logger.log(Status.PASS, "Google is accepting an Valid Username");
		waitFor(3);

		// Taking the Screenshot of the Error Message
		logger.log(Status.INFO, "Taking ScreenShot");
		try {
			takeScreenShotOnFailure();
		} catch (HeadlessException e) {
			e.printStackTrace();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		driver.close();
	}

	/****************** Enter Invalid MailID ***********************/
	public void invalidEmailId() {
		System.out.println("/*************************************************************/");
		System.out.println("                             Invalid Mail Id                    ");
		System.out.println("/*************************************************************/");
		// Fetching data from the Excel
		String[] data = null;
		try {
			data = ExcelUtils
					.readExcel(System.getProperty("user.dir") + "\\src\\java\\resources\\TestData\\TestData.xlsx");

		} catch (Exception e) {
			e.getMessage();
		}

		// Entering invalid Username
		logger.log(Status.INFO, "Entering the Invalid UserName");
		enterText("userName_Id", data[0]);
		waitFor(1);

		// Clicking on Next Button
		logger.log(Status.INFO, "Clicking on Next Button");
		elementClick("nextBtn_ClassName");
		waitFor(1);

		// Getting the Error Message
		logger.log(Status.INFO, "Capturing the Error Message");
		String errMsg = getMessage("errorMsg_ClassName");
		System.out.println(
				"\n-------------------------------------------------------------------------------------------------------------------------\n");
		System.out.println("\tThe Error Message is : " + errMsg);
		System.out.println(
				"\n-------------------------------------------------------------------------------------------------------------------------\n");

		logger.log(Status.PASS, "Google is not accepting an Invalid Username");

		waitFor(3);
		// Taking the Screenshot of the Error Message
		logger.log(Status.INFO, "Taking ScreenShot");
		try {
			takeScreenShotOnFailure();
		} catch (HeadlessException e) {
			e.printStackTrace();
		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

}
