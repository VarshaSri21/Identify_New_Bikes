package com.bikes.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.Status;
import com.bikes.baseUtils.baseUI;
import com.bikes.utils.ExcelUtils;

public class bikesHonda extends baseUI {

	public bikesHonda() throws IOException {
		super();
	}

	By BikeNames = By.xpath(prop.getProperty("BikeNames_xpath"));
	By BikesPrice = By.xpath(prop.getProperty("BikesPrice_xpath"));
	By ExpectedLaunch = By.xpath(prop.getProperty("ExpectedLaunch_xpath"));

	static int count = 0;
	static int count1 = 0;
	public static String[] bnames = new String[30];
	public static String[] bprice = new String[30];
	public static String[] bLaunch = new String[30];
	public static String[] result = new String[30];
	public static String[] popmodels = new String[30];
	public static String[] result1 = new String[30];

	/******************
	 * Select the Manufacturer from the Drop Down
	 ***********************/
	public void selectManufacturer() {

		logger.log(Status.INFO, "Bike type is going to be selected");
		dropdown("hbikes_Id");
		waitFor(1);
	}

	/****************** Click on the View More Details ***********************/
	public void viewMore(int x, int y) {
		try {
			logger.log(Status.INFO, "Moving down to click viewmore button");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(" + x + "," + y + ");");

		} catch (Exception e) {
			e.printStackTrace();
		}
		waitFor(1);
		elementClick("viewmore_Xpath");

	}

	/****************** Clicking on Honda bikes ***********************/
	public void HondaUpcomingBikes() {

		List<WebElement> bNames = driver.findElements(BikeNames);
		List<WebElement> bPrice = driver.findElements(BikesPrice);
		List<WebElement> eLaunch = driver.findElements(ExpectedLaunch);

		System.out.println("\n********************************************************************\n");
		System.out.println("\n The Upcoming Honda bikes details : \n");
		count = bNames.size();
		String priceTxt;

		try {
			for (int i = 0; i < count; i++) {
				priceTxt = bPrice.get(i).getText();
				float price = Float.parseFloat(priceTxt.replaceAll("Rs. ", "").replaceAll(" Lakh", ""));
				if (price < 4) {
					System.out.println("Bike Name : " + bNames.get(i).getText());
					System.out.println("Bike Price : " + bPrice.get(i).getText());
					System.out.println(eLaunch.get(i).getText());
					System.out.println("********************");

					bnames[count1] = bNames.get(i).getText();
					bprice[count1] = bPrice.get(i).getText();
					bLaunch[count1] = eLaunch.get(i).getText();
					result[count1] = "PASS";
					count1++;

				}

			}

			logger.log(Status.INFO, "Excel reports are going to be generated for Upcoming Honda Bikes in India");
			ExcelUtils.writeExcelData(
					System.getProperty("user.dir") + "\\src\\java\\resources\\TestData\\TestData.xlsx", bnames, bprice,
					bLaunch, result);
			reportPass("The Excel report is generated for the Upcoming bikes in India");

		} catch (Exception e) {
			reportFail(e.getMessage());

		}

		System.out.println("\n********************************************************************\n");
		System.out.println("Above bike prices are less than 4 lakhs");
		System.out.println("\n********************************************************************\n");

	}

}
