package com.bikes.pages;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.bikes.baseUtils.baseUI;
import com.bikes.utils.ExcelUtils;

public class usedCars extends baseUI {
	public String[] chennaiModels = new String[30];
	public String[] result = new String[30];
	public int count = 0;

	By popularModels = By.xpath(prop.getProperty("popularModels_Xpath"));

	public usedCars() throws IOException {
		super();
	}

	/****************** To get the Popular Models ***********************/
	public void getPopularModels() {
		List<WebElement> listOfModels = driver.findElements(popularModels);
		System.out.println("Number of popular models displayed are: " + listOfModels.size());
		Iterator<WebElement> i = listOfModels.iterator();
		while (i.hasNext()) {
			WebElement row = i.next();
			System.out.println(row.getText());
			chennaiModels[count] = row.getText();
			result[count] = "PASS";
			count++;
		}
		try {
			logger.log(Status.INFO, "Excel reports are going to be generated for Userd Cars in Chennai");
			ExcelUtils.WriteExcelData(
					System.getProperty("user.dir") + "\\src\\java\\resources\\TestData\\TestData.xlsx", chennaiModels,
					result);
			reportPass("The Excel report is generated for the Used Cars in Chennai");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Verify Place and Title of the page ***********************/
	public void verifyPlace() {
		String validLoc;
		String validLocResult;
		String UsedCarsPlace = driver.findElement(By.id("usedcarttlID")).getText();
		if (UsedCarsPlace.contains("Chennai")) {
			validLoc = "The used car details are retreived for Chennai";
			validLocResult = "PASS";
			banner("--------------");
			System.out.println(validLoc + "\t" + validLocResult);
			banner("--------------");
		} else {
			validLoc = "The Used cars details are not retreived for Chennai";
			validLocResult = "FAIL";
			banner("--------------");
			System.out.println(validLoc + "\t" + validLocResult);
			banner("--------------");

		}

	}

	public void banner(String value) {
		System.out.println("\n------------------------------------------------------" + value
				+ "--------------------------------------------\n");
	}

	public void waitFor(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
