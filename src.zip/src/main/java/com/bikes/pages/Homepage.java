package com.bikes.pages;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.Status;
import com.bikes.baseUtils.baseUI;

public class Homepage extends baseUI {

	public static String parent;

	By usedCar = By.xpath(prop.getProperty("usedCar_Xpath"));
	By chennai = By.xpath(prop.getProperty("chennai_Xpath"));

	public Homepage() throws IOException {
		super();
	}

	/****************** To Close the Popup ***********************/
	public void closePopup() {
		try {
			waitFor(10);
			logger.log(Status.INFO, "Waiting for the popup to appear");
			visibleOf("closebtn_Id");
			logger.log(Status.INFO, "The close button is going to be clicked");
			elementClick("closebtn_Id");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}

	}

	/****************** Click on Upcoming bikes ***********************/
	public void clickUcBikes() {

		try {
			logger.log(Status.INFO, "The cursor is going to be placed on NewBikes");
			moveCursor("newBikes_Xpath");
			logger.log(Status.INFO, "The cursor is placed on NewBikes");
			waitFor(1);
			logger.log(Status.INFO, "The Upcoming Bikes is going to be clicked");
			elementClick("upBikes_Xpath");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}

	}

	/****************** Selcting Chennai ***********************/
	public void selectChennai() {
		try {

			logger.log(Status.INFO, "The Curser is going to hover over 'Used Cars' option");
			Actions actions = new Actions(driver);
			WebElement uCars = driver.findElement(usedCar);
			waitFor(2);
			actions.moveToElement(uCars).build().perform();
			reportPass("Curser is moved to 'User Cars' top menu");
			waitFor(2);
			WebElement ch = driver.findElement(chennai);
			logger.log(Status.INFO, "'Chennai' option is going to be clicked");
			ch.click();
			waitFor(2);
			reportPass("'Chennai' option is clicked");

		} catch (Exception e) {
			reportFail(e.getMessage());
		}

	}

	/****************** To click on Login/Signup button ***********************/
	public void clickLogin() {
		try {
			// Click on the Login/Signup button
			logger.log(Status.INFO, "Clicking on Login/Signup Button");
			elementClick("loginSignup_Id");
			waitFor(2);

			// Click on Continue with Google
			logger.log(Status.INFO, "Clicking on Continue with Google Button");
			elementClick("continueGoogle_Id");

			// Switching to another window
			parent = driver.getWindowHandle();
			Set<String> diffWindows = driver.getWindowHandles();
			logger.log(Status.INFO, "Switching to the Child Window");

			for (String child : diffWindows) {

				if (!parent.equalsIgnoreCase(child)) {
					driver.switchTo().window(child);
				}
			}
			waitFor(2);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** To handle the Window ***********************/
	public void windowHandle() {
		driver.switchTo().window(parent);
		logger.log(Status.INFO, "Switching to the Parent Window");

		// closing the google signup popup message
		driver.findElement(By.id("report_submit_close_login")).click();
		logger.log(Status.INFO, "Closing the Continue with Google Button");

	}
}
