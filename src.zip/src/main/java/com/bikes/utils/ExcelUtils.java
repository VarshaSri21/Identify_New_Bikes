package com.bikes.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	public static File file;
	public static FileInputStream work_file;
	public static XSSFWorkbook workbook;
	public static XSSFSheet worksheet;
	public static XSSFRow row;
	public static FileOutputStream result_file;

	/******************
	 * Write the NewBikeDetails in Excel sheet
	 ***********************/
	public static void writeExcelData(String filePath, String[] bNames, String[] bPrice, String[] eLaunch,
			String[] result) throws IOException {

		try {

			File file = new File(filePath);
			FileInputStream workfile = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(workfile);
			XSSFSheet worksheet = workbook.getSheet("NewBikeDetails");
			XSSFRow row = worksheet.getRow(worksheet.getLastRowNum());
			int rCount = bNames.length;

			for (int i = 0; i < rCount; i++) {
				row = worksheet.createRow(i + 1);

				row.createCell(0).setCellValue(bNames[i]);
				row.createCell(1).setCellValue(bPrice[i]);
				row.createCell(2).setCellValue(eLaunch[i]);
				row.createCell(3).setCellValue(result[i]);

			}

			workfile.close();
			FileOutputStream fileout = new FileOutputStream(file);
			workbook.write(fileout);
			fileout.close();
			workbook.close();

		} catch (FileNotFoundException e) {
			System.out.println("Required file is not available");
			e.printStackTrace();
		}
	}

	/******************
	 * Write the UsedCarDetails in Excel sheet
	 ***********************/
	public static void WriteExcelData(String filePath, String[] popularModels, String[] result) throws IOException {

		try {
			File file = new File(filePath);
			FileInputStream workfile = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(workfile);
			XSSFSheet worksheet = workbook.getSheet("UsedCarDetails");
			row = worksheet.getRow(worksheet.getLastRowNum());
			int rowCount = popularModels.length;

			for (int i = 0; i < rowCount; i++) {

				row = worksheet.createRow(i + 1);
				row.createCell(0).setCellValue(popularModels[i]);
				row.createCell(1).setCellValue(result[i]);

			}

			result_file = new FileOutputStream(file);
			workbook.write(result_file);
			result_file.close();
			workbook.close();

		}

		catch (FileNotFoundException e) {
			System.out.println("The required file is not available in the given location");
			e.printStackTrace();
		}

	}

	/******************
	 * Read the Error message and Store it in ExcelSheet
	 ***********************/
	public static String[] readExcel(String filepath) {

		String[] data = new String[3];
		try {
			file = new File(filepath);
			work_file = new FileInputStream(file);
			workbook = new XSSFWorkbook(work_file);
			worksheet = workbook.getSheet("LoginDetails");
			row = worksheet.getRow(worksheet.getLastRowNum());

			for (int i = 0; i < 2; i++) {
				data[i] = String.valueOf(row.getCell(i));

			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return data;

	}
}
