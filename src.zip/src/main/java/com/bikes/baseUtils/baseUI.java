package com.bikes.baseUtils;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.bikes.utils.DateUtils;
import com.bikes.utils.ExtentReportManager;
import com.mongodb.diagnostics.logging.Logger;

public class baseUI {

	public static WebDriver driver;
	public static ExtentReports report = ExtentReportManager.getReportInstance();
	public static ExtentTest logger;
	public static Properties prop;

	public static String timestamp = DateUtils.getTimeStamp();
	public static Logger log;

	public static int i = 0;

	public baseUI() throws IOException {
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\java\\resources\\ObjectRepository\\Config.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			reportFail(e.getMessage());
		}

	}

	/****************** Setup Driver ***********************/
	public static WebDriver setupDriver() {

		System.out.println(
				"\n-------------------------------------------------------------------------------------------------\n");
		System.out.println("\n1)To choose chrome brower for execution ,type-'Chrome'");
		System.out.println("\n1)To choose Mozila FireFox brower for execution ,type-'firefox'");
		System.out.println("\n1)To choose edge brower for execution ,type-'edge'");
		System.out.println("\n1)To exit the execution ,type-'exit'");
		System.out.println(
				"\n-------------------------------------------------------------------------------------------------");
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		String browserName = scan.next();
		System.out.println(
				"-------------------------------------------------------------------------------------------------\n");
		try {
			if (browserName.equalsIgnoreCase("Chrome")) {
				driver = DriverSetup.getChromeDriver();
			} else if (browserName.equalsIgnoreCase("firefox")) {
				driver = DriverSetup.getFirefoxDriver();
			} else if (browserName.equalsIgnoreCase("Edge")) {
				driver = DriverSetup.getMSEdgeDriver();
			} else if (browserName.equalsIgnoreCase("exit")) {
				System.out.println("\n-------------------------Execution terminated----------------------\n");
				System.exit(0);
			} else {
				System.out
						.println("\n--------------------------Invalid selection of browser-------------------------\n");
				System.exit(0);
			}
		} catch (Exception e) {
			e.getStackTrace();
		}

		return driver;

	}

	/****************** Open URL ***********************/
	public void openURL(String websiteURLKey) {
		try {
			driver.get(prop.getProperty(websiteURLKey));
			reportPass(websiteURLKey + " Identified Successfully");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}

	}

	/****************** Get Element ***********************/
	public WebElement getElement(String locatorKey) {
		WebElement element = null;

		try {
			if (locatorKey.endsWith("_Id")) {
				element = driver.findElement(By.id(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_Xpath")) {
				element = driver.findElement(By.xpath(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_ClassName")) {
				element = driver.findElement(By.className(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_CSS")) {
				element = driver.findElement(By.cssSelector(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_LinkText")) {
				element = driver.findElement(By.linkText(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_PartialLinkText")) {
				element = driver.findElement(By.partialLinkText(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_Name")) {
				element = driver.findElement(By.name(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else {
				reportFail("Failing the Testcase, Invalid Locator " + locatorKey);
			}
		} catch (Exception e) {

			reportFail(e.getMessage());
			e.printStackTrace();
		}

		return element;
	}

	/****************** Enter Text ***********************/
	public void enterText(String locatorKey, String data) {
		try {
			getElement(locatorKey).sendKeys(data);
			reportPass(data + " - Entered successfully in locator Element : " + locatorKey);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Get Text ***********************/
	public String getMessage(String locatorKey) {
		String text = null;
		try {
			text = getElement(locatorKey).getText();
			reportPass(text + " - Received Message successfully from locator Element : " + locatorKey);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
		return text;
	}

	/****************** Get List ***********************/
	public String getList(String locatorKey) {
		String list = null;
		try {
			list = getElement(locatorKey).getText();
			reportPass(list + " - Received the List of elements successfully from locator Element : " + locatorKey);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
		return list;
	}

	/****************** Click Element ***********************/
	public void elementClick(String locatorKey) {
		try {
			getElement(locatorKey).click();
			reportPass(locatorKey + " : Element Clicked Successfully");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Move cursor ***********************/
	public void moveCursor(String locatorKey) {
		try {

			Actions action = new Actions(driver);
			action.moveToElement(getElement(locatorKey)).build().perform();
			reportPass(locatorKey + " : Element Moved Successfully");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Visible of ***********************/
	public void visibleOf(String locatorKey) {
		try {
			WebDriverWait wait1 = new WebDriverWait(driver, 30);
			wait1.until(ExpectedConditions.visibilityOf(getElement(locatorKey)));
			reportPass(locatorKey + " : Element visible Successfully");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** DropDown ***********************/
	public void dropdown(String locatorKey) {
		try {
			Select s1 = new Select(getElement(locatorKey));
			s1.selectByVisibleText("Honda");
			reportPass(locatorKey + " : Element selected Successfully");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Close the driver ***********************/
	public void tearDown() {
		driver.close();

	}

	/****************** Quit the driver ***********************/
	public void quitBrowser() {
		driver.quit();

	}

	/****************** Verify the Page Title ***********************/
	public void verifyPageTitle(String pageTitle) {
		try {
			String actualTite = driver.getTitle();
			logger.log(Status.INFO, "Actual Title is : " + actualTite);
			logger.log(Status.INFO, "Expected Title is : " + pageTitle);
			Assert.assertEquals(actualTite, pageTitle);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Wait For ***********************/
	public void waitFor(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/****************** Report Fail ***********************/
	public void reportFail(String reportString) {
		logger.log(Status.FAIL, reportString);
		try {
			takeScreenShotOnFailure();
		} catch (HeadlessException e) {
			e.printStackTrace();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		Assert.fail(reportString);
	}

	/****************** Report Pass ***********************/
	public void reportPass(String reportString) {
		logger.log(Status.PASS, reportString);
	}

	/****************** Taking ScreenShot ***********************/
	public static void takeScreenShotOnFailure() throws HeadlessException, AWTException {

		try {
			BufferedImage image = new Robot()
					.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize())); // Taking
																										// Screenshot
			ImageIO.write(image, "jpg",
					new File(System.getProperty("user.dir") + "\\ScreenShots\\Screenshot" + i + ".jpg"));
			logger.addScreenCaptureFromPath(System.getProperty("user.dir") + "\\ScreenShots\\Screenshot" + i + ".jpg");

		} catch (IOException e) {
			e.printStackTrace();
		}
		i++;
	}

}